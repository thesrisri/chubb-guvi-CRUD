import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  userList: any;
  constructor(private http: HttpClient) {
    this.getData()
  }

  ngOnInit(): void {

  }


  getData() {
    this.http.get('https://624e81a077abd9e37c87988c.mockapi.io/studentForm').subscribe((data) => {
      this.userList = data;
    })
  }
  onDelete(user: any) {
    this.http.delete(`https://624e81a077abd9e37c87988c.mockapi.io/studentForm/${user.id}`).subscribe((data) => {
      this.getData()
      alert('deleted')
    })
  }
}
